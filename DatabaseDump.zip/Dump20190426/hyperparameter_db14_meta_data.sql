CREATE DATABASE  IF NOT EXISTS `hyperparameter_db14` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `hyperparameter_db14`;
-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hyperparameter_db14
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `meta_data`
--

DROP TABLE IF EXISTS `meta_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `meta_data` (
  `meta_data_ID` int(11) DEFAULT NULL,
  `dataset_ID` int(11) DEFAULT NULL,
  `start_time` int(11) DEFAULT NULL,
  `target` text,
  `server_path` text,
  `data_path` text,
  `test_path` text,
  `max_models` int(11) DEFAULT NULL,
  `run_time` int(11) DEFAULT NULL,
  `run_id` text,
  `scale` text,
  `classification` text,
  `model_path` text,
  `balance` text,
  `balance_threshold` double DEFAULT NULL,
  `project` text,
  `end_time` int(11) DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  `run_path` text,
  `nthreads` int(11) DEFAULT NULL,
  `min_mem_size` int(11) DEFAULT NULL,
  `analysis` int(11) DEFAULT NULL,
  KEY `index2` (`meta_data_ID`),
  KEY `index2_` (`meta_data_ID`),
  KEY `index5_` (`run_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_data`
--

LOCK TABLES `meta_data` WRITE;
/*!40000 ALTER TABLE `meta_data` DISABLE KEYS */;
INSERT INTO `meta_data` VALUES (1,1,1555918564,'Claim','C:\\Users\\Ashmita\\Desktop\\Data Science Assignments\\Final Project\\n657f88e2','train.csv','',9,500,'wtiOmXHNa','FALSE','FALSE','','FALSE',0.2,'Claim_hyperparameters.json',1555918564,0,'C:\\Users\\Ashmita\\Desktop\\Data Science Assignments\\Final Project\\n657f88e2\\wtiOmXHNa',1,3,0),(2,1,1555920195,'','C:\\Users\\Ashmita\\Desktop\\Data Science Assignments\\Final Project\\n657f88e2\\wtiOmXHNa\\SZUMcPKvn\\IJlGWGLVi','','',9,1000,'efbvSQGg7','FALSE','FALSE','','FALSE',0.2,'',1555920195,0,'C:\\Users\\Ashmita\\Desktop\\Data Science Assignments\\Final Project\\n657f88e2\\wtiOmXHNa\\SZUMcPKvn\\IJlGWGLVi\\efbvSQGg7',1,1,0),(3,1,1555968866,'','C:\\Users\\Ashmita\\Desktop\\Data Science Assignments\\Final Project\\hyperparameter-db-project-ds14\\Python scripts\\Yurs3VOV1\\t98Izz7MB','','',9,1500,'PVxu8FKke','FALSE','FALSE','','FALSE',0.2,'',1555968866,0,'C:\\Users\\Ashmita\\Desktop\\Data Science Assignments\\Final Project\\hyperparameter-db-project-ds14\\Python scripts\\Yurs3VOV1\\t98Izz7MB\\PVxu8FKke',1,3,0),(4,1,1555972904,'','C:\\Users\\Ashmita\\Desktop\\Data Science Assignments\\Final Project\\hyperparameter-db-project-ds14\\Python scripts\\Yurs3VOV1\\t98Izz7MB\\PVxu8FKke','','',9,2000,'YF4LYH6AI','FALSE','FALSE','','FALSE',0.2,'',1555972904,0,'C:\\Users\\Ashmita\\Desktop\\Data Science Assignments\\Final Project\\hyperparameter-db-project-ds14\\Python scripts\\Yurs3VOV1\\t98Izz7MB\\PVxu8FKke\\YF4LYH6AI',1,2,0),(5,1,1555975812,'','C:\\Users\\Ashmita\\Desktop\\Data Science Assignments\\Final Project\\hyperparameter-db-project-ds14\\Python scripts\\Yurs3VOV1\\t98Izz7MB\\PVxu8FKke\\YF4LYH6AI','','',9,2500,'3oTEV9hn4','FALSE','FALSE','','FALSE',0.2,'',1555975812,0,'C:\\Users\\Ashmita\\Desktop\\Data Science Assignments\\Final Project\\hyperparameter-db-project-ds14\\Python scripts\\Yurs3VOV1\\t98Izz7MB\\PVxu8FKke\\YF4LYH6AI\\3oTEV9hn4',1,2,0);
/*!40000 ALTER TABLE `meta_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-26 19:45:42
